# 图：来源与使用说明

## 主图

- 文件：`assets/figures/china_cbec_trade_2020_2024.png`
- 分辨率：3228 × 1839 px。
- 数据来源：中国海关总署 2020—2024 年跨境电商进出口初步统计。
- 推荐图注：`Source: General Administration of Customs of China (2020–2024); authors’ visualisation. 2024 value is preliminary.`
- 允许的处理：可通过本包 Python 脚本重新配色、翻译或改变尺寸；不得移除来源或改变数据含义。

## 备用图

- 文件：`assets/figures/china_global_consumer_reach_2016_2023.png`
- 分辨率：3078 × 1811 px。
- 数据来源：IPC Cross-Border E-commerce Shopper Survey 2023，经 HKTDC 2024 演示稿第 8 页公开呈现。
- 推荐图注：`Source: IPC Cross-Border E-commerce Shopper Survey 2023, reproduced in HKTDC (2024); authors’ visualisation.`
- 口径提醒：37% 是“受访者最近一次跨境网购来自中国”的比例，不是销售额或全球市场份额。

## 版权

两张 PNG 均为本包依据公开数值重绘，不是对官方原图的高清修复。官方网页、报告和调查的再使用条款未完全明确，均应保留署名；用于公开发表或商业使用前仍需核查许可。
