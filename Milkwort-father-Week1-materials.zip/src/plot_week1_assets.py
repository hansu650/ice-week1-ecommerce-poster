#!/usr/bin/env python3
"""Regenerate the two poster-ready PNG charts from the packaged CSV files."""

from pathlib import Path
import csv

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
OUT_DIR = ROOT / "assets" / "figures"
NAVY = "#16324F"
TEAL = "#14B8A6"
ORANGE = "#F59E0B"
GREY = "#5B6573"


def read_csv(path: Path):
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def apply_style():
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "axes.titleweight": "bold",
            "axes.edgecolor": "#CAD3DE",
            "axes.labelcolor": GREY,
            "xtick.color": GREY,
            "ytick.color": GREY,
            "figure.facecolor": "white",
            "axes.facecolor": "white",
        }
    )


def main_chart():
    rows = read_csv(DATA_DIR / "china_cbec_trade_2020_2024.csv")
    years = np.array([int(row["year"]) for row in rows])
    values = np.array([float(row["cbec_trade_rmb_trillion"]) for row in rows])

    fig, ax = plt.subplots(figsize=(16, 9), dpi=225)
    fig.subplots_adjust(left=0.09, right=0.94, top=0.78, bottom=0.18)
    ax.fill_between(years, values, 1.4, color=TEAL, alpha=0.11)
    ax.plot(years, values, color=TEAL, linewidth=4, marker="o", markersize=11,
            markerfacecolor="white", markeredgewidth=3)
    ax.scatter([2024], [values[-1]], s=270, color=ORANGE, zorder=5, edgecolor="white", linewidth=2)

    for year, value in zip(years, values):
        ax.text(year, value + 0.07, f"{value:.2f}", ha="center", va="bottom",
                fontsize=15, color=NAVY, weight="bold")

    ax.set_xlim(2019.65, 2024.35)
    ax.set_ylim(1.4, 2.9)
    ax.set_xticks(years)
    ax.set_yticks([1.5, 2.0, 2.5])
    ax.set_ylabel("RMB trillion", fontsize=13)
    ax.grid(axis="y", color="#E4E9EF", linewidth=1.2)
    ax.spines[["top", "right", "left"]].set_visible(False)
    ax.tick_params(axis="both", labelsize=12, length=0)

    fig.text(0.09, 0.92, "China’s Cross-border E-commerce Trade Nearly Doubled",
             fontsize=28, weight="bold", color=NAVY)
    fig.text(0.09, 0.855, "Import and export value, 2020–2024 (RMB trillion)",
             fontsize=16, color=GREY)
    ax.annotate("2024 snapshot\nRMB 2.63 tn  |  +10.8% YoY\n≈6% of China’s merchandise trade",
                xy=(2024, values[-1]), xytext=(2022.75, 1.72),
                fontsize=14, color=NAVY, weight="bold",
                bbox=dict(boxstyle="round,pad=0.65", facecolor="#FFF7E6", edgecolor=ORANGE, linewidth=1.5),
                arrowprops=dict(arrowstyle="->", color=ORANGE, linewidth=2))
    fig.text(0.09, 0.07,
             "Source: General Administration of Customs of China (2020–2024). 2024 value is preliminary.\n"
             "Measure: total cross-border e-commerce imports + exports; values may differ from later revised releases.",
             fontsize=10.5, color=GREY)
    fig.savefig(OUT_DIR / "china_cbec_trade_2020_2024.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def backup_chart():
    rows = read_csv(DATA_DIR / "ipc_purchase_source_china_2016_2023.csv")
    years = [str(int(row["year"])) for row in rows]
    shares = [float(row["share_percent"]) for row in rows]

    fig, ax = plt.subplots(figsize=(16, 9), dpi=225)
    fig.subplots_adjust(left=0.12, right=0.92, top=0.76, bottom=0.22)
    x = np.arange(len(years))
    bars = ax.bar(x, shares, width=0.46, color=["#9AB6C9", TEAL], zorder=3)
    for bar, share in zip(bars, shares):
        ax.text(bar.get_x() + bar.get_width() / 2, share + 1.3, f"{share:.0f}%",
                ha="center", va="bottom", fontsize=24, weight="bold", color=NAVY)

    ax.set_xticks(x, years)
    ax.set_ylim(0, 45)
    ax.set_yticks([0, 10, 20, 30, 40], labels=["0%", "10%", "20%", "30%", "40%"])
    ax.grid(axis="y", color="#E4E9EF", linewidth=1.2, zorder=0)
    ax.spines[["top", "right", "left"]].set_visible(False)
    ax.tick_params(axis="both", labelsize=13, length=0)
    ax.set_ylabel("Share of surveyed consumers", fontsize=13)

    fig.text(0.12, 0.91, "China’s Global Consumer Reach Is Expanding",
             fontsize=29, weight="bold", color=NAVY)
    fig.text(0.12, 0.84,
             "Share whose most recent cross-border online purchase came from China",
             fontsize=16, color=GREY)
    ax.text(0.5, 17, "+11 percentage points", ha="center", va="center",
            fontsize=16, color=NAVY, weight="bold",
            bbox=dict(boxstyle="round,pad=0.55", facecolor="#FFF7E6", edgecolor=ORANGE, linewidth=1.5))
    fig.text(0.12, 0.075,
             "Source: IPC Cross-Border E-commerce Shopper Survey 2023, as reproduced in HKTDC (2024).\n"
             "2023: 32,510 consumers in 41 markets; trend sample 23,005. This is respondent share—not sales or market share.",
             fontsize=10.5, color=GREY)
    fig.savefig(OUT_DIR / "china_global_consumer_reach_2016_2023.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)


if __name__ == "__main__":
    apply_style()
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    main_chart()
    backup_chart()
    print(f"Charts saved to: {OUT_DIR}")
