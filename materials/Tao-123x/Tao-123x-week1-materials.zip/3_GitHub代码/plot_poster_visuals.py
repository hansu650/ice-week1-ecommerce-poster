# -*- coding: utf-8 -*-
"""
China Cross-Border E-Commerce (CBEC) Poster Visual Generation Pipeline
Module: MMU & HBU Joint Institute ICE 1CWK100 Week 1
Author: Tao Jiacheng
"""

import pandas as pd
import os

def load_data():
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    macro_csv = os.path.join(base_dir, '2_数据', 'china_cbec_export_macro_2018_2026.csv')
    region_csv = os.path.join(base_dir, '2_数据', 'cbec_destination_market_shares_2025_2026.csv')
    product_csv = os.path.join(base_dir, '2_数据', 'shein_product_pricing_sample_2025.csv')
    
    df_macro = pd.read_csv(macro_csv)
    df_region = pd.read_csv(region_csv)
    df_product = pd.read_csv(product_csv)
    return df_macro, df_region, df_product

def summarize_key_metrics():
    df_macro, df_region, df_product = load_data()
    print("=" * 60)
    print("China Cross-Border E-Commerce Key 2025-2026 Metrics")
    print("=" * 60)
    print(f"2025 CBEC Export Volume: {df_macro[df_macro['Year']=='2025']['CBEC_Export_Trillion_RMB'].values[0]} Trillion RMB")
    print(f"2025 Share of Total China Goods Exports: {df_macro[df_macro['Year']=='2025']['Share_of_Total_Goods_Export_Pct'].values[0]}%")
    print("\nTop Export Destination Shares (2025-2026):")
    for _, row in df_region.iterrows():
        print(f"- {row['Region']}: {row['Market_Share_Pct_2025']}% (YoY Growth: +{row['YoY_Growth_Rate_Pct']}%)")
    
    print("\nMicroscopic Business Model Benchmark (LATR vs Traditional):")
    shein_price = df_product[df_product['brand_platform']=='SHEIN']['sale_price_usd'].astype(float).mean()
    zara_price = df_product[df_product['brand_platform']=='Zara']['sale_price_usd'].astype(float).mean()
    print(f"- SHEIN Avg Sample Price: ${shein_price:.2f} | Zara Avg Sample Price: ${zara_price:.2f}")
    print("=" * 60)

if __name__ == '__main__':
    summarize_key_metrics()
