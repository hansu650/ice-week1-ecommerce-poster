# ICE 1CWK100 Week 1: E-commerce Trends

## 📦 项目背景 (Project Context)
- **课题 (Module)**: Industry & Community Engagement (ICE 1CWK100)
- **主题 (Topic)**: From Domestic Scale to Global Reach: How China’s Cross-border E-commerce Is Reshaping Global Retail (从本土规模到全球触达：中国跨境电商如何重塑全球零售)
- **交付物 (Deliverable)**: Week 1 小组海报 (Group Poster)

## 📂 文件夹结构说明 (Directory Structure)

本项目的所有素材均已按照学术规范和海报排版需求进行整理：

### `1_论文与图表/` (Charts & Papers)
- 包含基于海关总署和行业报告数据绘制的**高清 SVG 图表**，可无损导入 Figma / Adobe Illustrator 进行海报排版。
- `论文索引与核心图表说明.md`: 提供了所有图表背后的学术文献支撑。
- `引用与参考文献_Harvard_Referencing.txt`: 标准哈佛引用格式，可直接复制到海报的 Reference 区域。

### `2_数据/` (Datasets)
- 包含 2025-2026 年中国跨境电商出口规模、目的国市场份额（Shein/Temu 等）的 **原始 CSV 数据集**。
- `数据字段字典与统计口径说明.md`: 解释了数据来源和字段含义，确保数据引用的严谨性。

### `3_GitHub代码/` (Code & Scripts)
- 包含用于生成数据可视化图表和模拟柔性供应链（Agile Supply Chain）的 **Python 源代码**。
- 可作为数据分析步骤的 Evidence 提交。

### `4_海报实景与参考原图/` (Original Images)
- 包含可免费商用（CC0/Unsplash License）的高清实景原图（远洋货轮物流、自动化仓储、电商支付等）。
- 适用于海报的背景、插图或排版素材，避免了直接截取网络图片带来的版权风险和模糊问题。

## 🚀 如何使用 (How to Use)
1. **预览所有素材**: 双击根目录下的 `海报素材总览与排版指引.html` 即可在浏览器中直观预览所有图表和排版建议。
2. **排版海报**: 建议使用 Figma 或 Canva，将 `1_论文与图表/` 中的 `.svg` 矢量图以及 `4_海报实景与参考原图/` 中的 `.jpg` 高清图直接拖入画布。
3. **编写文案**: 参考 `海报素材总览与排版指引.html` 中的 Storyline（故事线）进行分块文字排版。

## ⚠️ 注意事项 (Notes)
- 所有的图表和数据均遵循 ICE 模块的严谨性要求，附有数据来源。
- 若需要调整图表颜色以适应海报主色调，可直接编辑 `3_GitHub代码/` 中的 Python 脚本重新生成，或在矢量软件中直接修改 SVG 颜色。
