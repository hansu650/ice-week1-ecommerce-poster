# Official reports and source pages

本目录只保留发布方链接，不在公开仓库中重新分发许可不明确的完整 PDF。

## China e-commerce report

- 商务部《中国电子商务报告（2024）》发布页：  
  <https://dzswgf.mofcom.gov.cn/news/5/2025/3/1741656544282.html>
- 报告 PDF：  
  <https://dzswgf.mofcom.gov.cn/news_attachments/81d19ce55784aa574b4d579ed657ddc9941eac7a.pdf>

## IPC survey

- IPC Cross-Border E-commerce Shopper Survey 2023：  
  <https://www.ipc.be/services/business-framework/cross-border-shopper-survey/2023>
- IPC 交互概览：  
  <https://e.infogram.com/1c33df12-a0ea-49ce-89fa-fd575d0c1fdc?src=embed>

## HKTDC presentation

- *Digital Trade Transformation: Opportunities and Challenges* (2024)：  
  <https://www.aof.org.hk/docs/default-source/hkimr/conference-workshop/panel-2_1_irina-fan.pdf?sfvrsn=315bce5b_2>

访问、下载或再次使用这些材料时，应遵守对应发布方的最新条款。

