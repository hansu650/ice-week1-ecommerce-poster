# 备用素材包：IPC消费者调查——中国商品的全球触达扩大

## 1. 海报用途

- **这套素材能说明什么？** 在 IPC 跨境电商购物者调查的趋势样本中，最近一次跨境网购商品来自中国的受访者比例由 2016 年 26% 增至 2023 年 37%。
- **如何回答“中国电商的增长、趋势以及对全球产业的影响”？** 它从消费者端补充主素材，说明中国不仅有贸易规模，而且在跨境购物来源中具有更广的全球触达；可进一步讨论平台、价格、品类和履约网络对全球零售竞争的影响。
- **建议位置：** 海报右下角或“Global Reach”小节，约占 20%—25% 版面；不要替代主图。

## 2. 图片或论文图

- **图片标题：** Products from China Are Consumers’ Most Popular Cross-border E-commerce Purchases（HKTDC 演示稿标题）；本包重绘标题为 China’s Global Consumer Reach Is Expanding。
- **图片直接访问链接：** [IPC 2023 交互概览](https://e.infogram.com/1c33df12-a0ea-49ce-89fa-fd575d0c1fdc?src=embed)；本仓库高清重绘图为 `assets/figures/china_global_consumer_reach_2016_2023.png`。
- **原论文/报告链接或 DOI：** [IPC Survey 2023](https://www.ipc.be/services/business-framework/cross-border-shopper-survey/2023)；[HKTDC Digital Trade Transformation PDF](https://www.aof.org.hk/docs/default-source/hkimr/conference-workshop/panel-2_1_irina-fan.pdf?sfvrsn=315bce5b_2)；无 DOI。
- **论文名称、作者、年份：** *Digital Trade Transformation: Opportunities and Challenges*，Irina Fan / HKTDC Research，2024；基础调查为 IPC Cross-Border E-commerce Shopper Survey 2023。
- **图号和页码：** HKTDC 演示稿第 8 页；未标正式图号。
- **图片分辨率：** 本包重绘图 3078 × 1811 px，PNG，sRGB。
- **图片展示的主要结论：** 2016—2023 年，相关受访者比例提高 11 个百分点（26%→37%）。
- **许可类型：** IPC/HKTDC 网页和演示稿未在页面明确给出开放改编许可，**许可待核查**。
- **是否允许修改、翻译、重新配色或高清修复：** 原图许可不清；建议只取公开数值后重绘，并保留完整定义和来源。
- **是否需要署名：** 需要。建议署名：`Source: IPC Cross-Border E-commerce Shopper Survey 2023, reproduced in HKTDC (2024); authors’ visualisation.`

## 3. 数据

- **数据集名称：** IPC 跨境消费者最近一次购买来源为中国的比例（2016、2023）
- **数据下载页面：** [IPC Cross-Border E-commerce Shopper Survey 2023](https://www.ipc.be/services/business-framework/cross-border-shopper-survey/2023)
- **CSV/JSON/Parquet直接链接（如果有）：** IPC 未公开调查微观 CSV；本仓库整理的图表数据为 `data/ipc_purchase_source_china_2016_2023.csv`。
- **原始数据来源：** IPC 2023 跨境电商购物者调查；HKTDC 2024 演示稿第 8 页公开呈现趋势数值。
- **年份范围：** 2016—2023（公开图只使用 2016 和 2023 两个端点）。
- **样本量：** 2023 完整调查 32,510 名消费者、41 个市场；趋势样本 23,005。公开图没有单列 2016 年单年样本量。
- **主要字段：** `year`、`share_percent`、`measure`、`sample_note`。
- **单位和统计口径：** 百分比；“受访者最近一次跨境在线购买来自中国”的比例。
- **数据类型：** 真实预处理数据。
- **预处理：** 从公开图提取 26% 和 37%，补入指标定义与样本说明；无推算、无插值。
- **数据许可证：** 微观数据不公开，公开汇总值的再使用条款不明确，**许可待核查**。
- **数据能画成什么图：** 两期柱形图、斜率图、+11 个百分点 KPI；不适合画连续年度趋势线。

## 4. GitHub代码

- **仓库链接：** [UN Comtrade/comtradeapicall](https://github.com/uncomtrade/comtradeapicall)（仅作通用贸易流扩展）；IPC 没有发现公开官方代码仓库。
- **具体Notebook或Python文件链接：** [Bilateral trade matrix notebook](https://github.com/uncomtrade/comtradeapicall/blob/main/examples/example%20bilateral%20trade%20matrix%20view.ipynb)；本仓库重绘文件为 `src/plot_week1_assets.py`。
- **代码许可证：** 上游仓库 MIT；IPC 数据许可另行核查。
- **使用语言：** Python。
- **需要的主要库：** matplotlib、numpy；上游示例另需 pandas 和 comtradeapicall。
- **代码能生成什么图：** 本包脚本生成 26% 与 37% 的对比柱形图；上游代码可补充中国与伙伴国的一般商品贸易流向，但不能直接代表跨境电商。
- **是否包含数据清洗：** 本包仅做字段读取和类型转换；无插值。
- **是否包含原始数据：** 不包含 IPC 微观问卷数据；包含公开图表数值整理的 CSV。
- **是否能够直接运行：** 本包脚本可直接运行；上游 API 完整查询可能需要 key。

## 5. 建议处理方式

- **根据原数据重新画图**（首选）
- 翻译文字
- 调整配色
- 只参考论文结论，不使用原图

## 6. 风险检查

- **图片是否带水印：** 本包重绘图无水印；交互图可能带 Infogram/发布平台标识。
- **图片是否禁止修改：** 原图改编许可不清，许可待核查；建议使用本包重绘图。
- **数据是否可能为模拟或缺少来源：** 非模拟，但只有两个公开端点，且微观数据未公开。
- **GitHub是否没有许可证：** 上游 UN Comtrade 仓库有 MIT；IPC 无公开配套仓库。
- **数据与图片是否真的对应：** 对应；本包图使用 CSV 中 26% 和 37%。
- **是否存在年份或统计口径不一致：** 2016 与 2023 来自趋势比较；2023 同时有完整样本与趋势样本两个规模，描述时要写清。该指标是“购买来源比例”，绝不是中国全球电商销售份额。

## 7. 最终提交内容

1. **图片或可访问论文链接：** [HKTDC 演示稿 PDF](https://www.aof.org.hk/docs/default-source/hkimr/conference-workshop/panel-2_1_irina-fan.pdf?sfvrsn=315bce5b_2)
2. **数据集或数据下载链接：** [IPC Survey 2023](https://www.ipc.be/services/business-framework/cross-border-shopper-survey/2023)
3. **GitHub仓库或具体代码链接：** [UN Comtrade 双边贸易矩阵 Notebook](https://github.com/uncomtrade/comtradeapicall/blob/main/examples/example%20bilateral%20trade%20matrix%20view.ipynb)

推荐这套素材作为“全球触达”补充，因为消费者端的26%到37%变化直观易懂，能连接主图的贸易规模与海外需求；但必须明确它是调查比例，而非销售额或全球市场份额。
