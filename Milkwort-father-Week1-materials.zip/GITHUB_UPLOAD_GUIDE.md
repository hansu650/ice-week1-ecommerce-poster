# GitHub 上传说明

## 网页上传（最适合新手）

1. 在 GitHub 创建一个空仓库，例如 `china-cross-border-ecommerce-week1`。
2. 不要勾选自动创建 README、`.gitignore` 或 License，避免与本包文件冲突。
3. 解压本压缩包；不要只把 ZIP 本身上传到仓库。
4. 进入解压后的目录，确认能直接看到 `README.md`、`data`、`src` 等内容。
5. 在 GitHub 仓库页面选择 **Add file → Upload files**。
6. 将解压后目录内的全部文件和文件夹拖入上传区域，然后提交。

本仓库文件数量少于 GitHub 网页单次 100 个文件的限制，且所有单文件均远小于网页上传的 25 MiB 上限，不需要 Git LFS。

## Git 命令上传

```bash
git init
git add .
git commit -m "Add Week 1 cross-border e-commerce poster materials"
git branch -M main
git remote add origin https://github.com/YOUR_NAME/YOUR_REPOSITORY.git
git push -u origin main
```

将 `YOUR_NAME/YOUR_REPOSITORY` 替换为自己的 GitHub 用户名和仓库名。不要在仓库中提交账号密码、API Key 或访问令牌。

## 上传后检查

- 仓库首页能显示 `README.md` 和两张图片。
- `Actions` 页面中的 `Validate repository` 工作流通过。
- `src/plot_week1_assets.py` 可运行并重新生成两张图。
- 仓库若设为公开，仍需保留来源和第三方权利说明。

