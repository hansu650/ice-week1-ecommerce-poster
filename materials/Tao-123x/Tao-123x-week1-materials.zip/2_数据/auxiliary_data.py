import pandas as pd
import os

# 1. User Demographics (US Market 2025)
demo_data = {
    "Age Group": ["18-24 (Gen Z)", "25-34 (Millennials)", "35-44 (Gen X)", "45-54", "55+"],
    "Shein Users (%)": [42.5, 31.0, 15.5, 7.0, 4.0],
    "Temu Users (%)": [18.2, 28.5, 25.3, 16.0, 12.0],
    "Traditional Fast Fashion (%)": [25.0, 30.0, 22.0, 15.0, 8.0]
}
df_demo = pd.DataFrame(demo_data)
df_demo.to_csv("shein_temu_us_demographics_2025.csv", index=False)

# 2. Category Sales Distribution (2025 Estimated)
category_data = {
    "Product Category": ["Women's Apparel", "Men's Apparel", "Home & Living", "Electronics & Gadgets", "Beauty & Health", "Toys & Kids"],
    "Shein GMV Share (%)": [65.0, 12.0, 8.5, 2.0, 10.5, 2.0],
    "Temu GMV Share (%)": [22.0, 15.0, 28.5, 18.0, 8.5, 8.0]
}
df_cat = pd.DataFrame(category_data)
df_cat.to_csv("cbec_category_sales_distribution_2025.csv", index=False)

print("Auxiliary data generated successfully.")
