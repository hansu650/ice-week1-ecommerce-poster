# China Cross-border E-commerce — Week 1 Poster Dataset

本仓库为课程 **Industry & Community Engagement — Week 1: E-commerce Trends** 的小组海报提供可核验、可编辑、可复现的素材。

海报主题：

> **From Domestic Scale to Global Reach: How China’s Cross-border E-commerce Is Reshaping Global Retail**

## 核心结论

- 中国跨境电商进出口从 **2020 年 1.69 万亿元**增至 **2024 年 2.63 万亿元**。
- 按本仓库采用的海关初步统计序列计算，2020—2024 年 CAGR 约为 **11.7%**。
- 2024 年跨境电商进出口约占中国货物贸易总值的 **6%**。
- IPC 趋势样本显示，最近一次跨境网购来自中国的受访者比例从 **2016 年 26%**增至 **2023 年 37%**。该比例不是销售额市场份额。

## Poster-ready figures

### Domestic scale

![China CBEC trade, 2020–2024](assets/figures/china_cbec_trade_2020_2024.png)

### Global reach

![Share whose latest cross-border purchase came from China](assets/figures/china_global_consumer_reach_2016_2023.png)

## 仓库结构

```text
.
├── README.md
├── assets/figures/       # 海报高清图
├── data/                 # CSV、Excel与来源链接
├── docs/                 # 主/备用素材、口径、海报和代码说明
├── references/           # 官方报告与调查的访问链接
├── src/                  # Python重绘脚本
├── requirements.txt
└── .github/workflows/    # GitHub Actions自动检查
```

## 运行方法

先创建虚拟环境：

```bash
python -m venv .venv
```

Windows PowerShell：

```powershell
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python src/plot_week1_assets.py
```

macOS / Linux：

```bash
source .venv/bin/activate
python -m pip install -r requirements.txt
python src/plot_week1_assets.py
```

脚本会从 `data/` 读取 CSV，并覆盖生成 `assets/figures/` 中的两张 PNG。

## 资料导航

- [主素材包详细说明](docs/MAIN_MATERIAL_GUIDE.md)
- [备用素材包详细说明](docs/BACKUP_MATERIAL_GUIDE.md)
- [海报布局与英文文案](docs/POSTER_GUIDE.md)
- [数据口径说明](docs/DATA_NOTES.md)
- [图片来源与再使用说明](docs/SOURCE_AND_REUSE_NOTES.md)
- [代码及上游仓库说明](docs/CODE_NOTES.md)
- [第三方资料权利说明](THIRD_PARTY_NOTICES.md)
- [GitHub上传说明](GITHUB_UPLOAD_GUIDE.md)

## 重要口径

1. 主序列是跨境电商**进口与出口合计**，不是只统计出口。
2. 2024 年 2.63 万亿元为海关初步统计；不要与后续修订值或修订同比混合。
3. IPC 的 26% 与 37% 是调查受访者最近一次购买来源比例，不是中国在全球电商销售额中的份额。
4. UN Comtrade 是一般商品贸易数据，不能直接标为跨境电商数据。

## 使用与署名

本仓库未授予覆盖全部内容的统一许可证。公开报告、政府网页、调查汇总值及上游代码分别适用其原始权利和条款。课堂海报使用时必须保留来源，详情见 `THIRD_PARTY_NOTICES.md`。
