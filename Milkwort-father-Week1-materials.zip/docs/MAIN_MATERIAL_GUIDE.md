# 主素材包：海关官方序列——中国跨境电商从规模增长走向全球零售影响

## 1. 海报用途

- **这套素材能说明什么？** 中国跨境电商进出口规模从 2020 年 1.69 万亿元增至 2024 年 2.63 万亿元，按同一组初步统计序列计算，四年复合年增长率约 11.7%。
- **如何回答“中国电商的增长、趋势以及对全球产业的影响”？** 它直接证明规模与趋势；2024 年约占中国货物贸易总值 6%，说明跨境电商已成为贸易和全球零售供应链中不可忽视的渠道。全球影响的机制可在海报中概括为“平台获客—数字支付—跨境物流—海外履约—直接触达消费者”。
- **建议位置：** 海报中部或左侧主视觉，约占 45%—55% 版面；右侧配 2.63、11.7%、6% 三个 KPI。

## 2. 图片或论文图

- **图片标题：** China’s Cross-border E-commerce Trade Nearly Doubled
- **图片直接访问链接：** 本仓库 `assets/figures/china_cbec_trade_2020_2024.png`；此图为依据官方数据重新绘制，无第三方原图直链。
- **原论文/报告链接或 DOI：** [商务部《中国电子商务报告（2024）》发布页](https://dzswgf.mofcom.gov.cn/news/5/2025/3/1741656544282.html)；[报告 PDF](https://dzswgf.mofcom.gov.cn/news_attachments/81d19ce55784aa574b4d579ed657ddc9941eac7a.pdf)；无 DOI。
- **论文名称、作者、年份：** 《中国电子商务报告（2024）》，中华人民共和国商务部电子商务和信息化司，2025 年发布。
- **图号和页码：** 本包图为原创重绘，不对应报告固定图号；历年数值逐年取自海关总署官方发布。
- **图片分辨率：** 3228 × 1839 px，PNG，sRGB。
- **图片展示的主要结论：** 2020—2024 年跨境电商进出口由 1.69 增至 2.63 万亿元，近乎翻倍；2024 年同比增长 10.8%，约占货物贸易总值 6%。
- **许可类型：** 本包绘图代码为自制；海关网页及商务部报告的数据/内容再使用许可未明确，**许可待核查**。
- **是否允许修改、翻译、重新配色或高清修复：** 建议依据本包数据重新绘图、翻译或调整配色；不要把官方报告版式或图形直接当作开放许可素材。
- **是否需要署名：** 需要。建议署名：`Source: General Administration of Customs of China (2020–2024); authors’ visualisation.`

## 3. 数据

- **数据集名称：** 中国跨境电商进出口规模（2020—2024，海关初步统计汇编）
- **数据下载页面：** [2020](https://www.customs.gov.cn/customs/2021-02/22/article_2025121409263636513.html)；[2021](https://www.customs.gov.cn/customs/xwfb34/302330/4124672/index.html)；[2022](https://www.customs.gov.cn/customs/xwfb34/302330/4795072/index.html)；[2023](https://www.customs.gov.cn/customs/xwfb34/302330/5625690/index.html)；[2024](https://www.customs.gov.cn/customs/2025-01/14/article_2025121410054066028.html)
- **CSV/JSON/Parquet直接链接（如果有）：** 官方页面未提供结构化直链；本仓库整理为 `data/china_cbec_trade_2020_2024.csv`。
- **原始数据来源：** 中华人民共和国海关总署历年新闻发布/统计发布。
- **年份范围：** 2020—2024。
- **样本量：** 5 个年度观测值；属于官方汇总统计，不是抽样微观数据。
- **主要字段：** `year`、`cbec_trade_rmb_trillion`、`yoy_percent`、`statistical_status`、`source_url`。
- **单位和统计口径：** 万亿元人民币；跨境电商**进口与出口合计**；同比单位为百分比。2024 年 2.63 万亿元为初步统计。
- **数据类型：** 真实预处理数据。
- **预处理：** 从五个海关网页提取年度总值、同比和备注；统一把金额换算为“万亿元人民币”；补入来源 URL；未插值、未平滑、未估算缺失值。
- **数据许可证：** 政府网页公开数据，但未发现明确开放数据许可证，**许可待核查**；课堂使用仍应注明来源。
- **数据能画成什么图：** 年度折线图、面积图、同比柱形图、2020=100 指数图、CAGR/KPI 卡片。

## 4. GitHub代码

- **仓库链接：** [UN Comtrade/comtradeapicall](https://github.com/uncomtrade/comtradeapicall)
- **具体Notebook或Python文件链接：** [Top traded products notebook](https://github.com/uncomtrade/comtradeapicall/blob/main/examples/example%20tracking%20top%20traded%20products.ipynb)；[Bilateral trade matrix notebook](https://github.com/uncomtrade/comtradeapicall/blob/main/examples/example%20bilateral%20trade%20matrix%20view.ipynb)；本仓库直接重绘文件为 `src/plot_week1_assets.py`。
- **代码许可证：** 上游仓库 MIT；本包自制脚本可用于本课程小组海报和数据重绘。
- **使用语言：** Python。
- **需要的主要库：** matplotlib、numpy；上游 API 示例还使用 pandas、urllib3/comtradeapicall。
- **代码能生成什么图：** 本包脚本直接生成主图和备用图；上游 Notebook 可做中国与贸易伙伴的商品流向和双边贸易矩阵，用作扩展背景。
- **是否包含数据清洗：** 本包脚本进行字段读取和数值类型转换，不含插值或异常值修正；上游示例含 API 结果整理。
- **是否包含原始数据：** 本包包含从官方网页摘录并标准化的 CSV，不包含海关微观原始记录；上游仓库不打包 UN Comtrade 全量数据。
- **是否能够直接运行：** 本包脚本可直接运行；上游部分完整 API 查询可能需要 UN Comtrade key 和网络。

## 5. 建议处理方式

- **根据原数据重新画图**（首选）
- 调整配色
- 翻译文字
- 参考原图布局重新设计
- 如使用本包 PNG，可直接引用并保留来源行

## 6. 风险检查

- **图片是否带水印：** 否。
- **图片是否禁止修改：** 本包为重绘图，可通过脚本修改；官方报告原图许可待核查，不建议直接改图。
- **数据是否可能为模拟或缺少来源：** 非模拟；每年均保留海关页面来源。
- **GitHub是否没有许可证：** 上游仓库有 MIT 许可证。
- **数据与图片是否真的对应：** 对应；PNG、Excel 图表和 CSV 使用同一组五年数据。
- **是否存在年份或统计口径不一致：** 有潜在风险。2.63 万亿元是 2024 年初步统计；商务部后续报告可能采用修订值。海报必须整套使用同一版本，不要把 2.63 与修订后的同比数字拼接。

## 7. 最终提交内容

1. **图片或可访问论文链接：** [商务部报告 PDF](https://dzswgf.mofcom.gov.cn/news_attachments/81d19ce55784aa574b4d579ed657ddc9941eac7a.pdf)
2. **数据集或数据下载链接：** [海关总署 2024 发布](https://www.customs.gov.cn/customs/2025-01/14/article_2025121410054066028.html)（其余年份见上文）
3. **GitHub仓库或具体代码链接：** [UN Comtrade/comtradeapicall](https://github.com/uncomtrade/comtradeapicall)

推荐这套素材，因为它以海关连续年度真实统计为核心，能清晰证明中国跨境电商的规模增长，并用货物贸易占比连接全球产业影响；数据、图表与代码相互对应，最适合作为海报主证据。
