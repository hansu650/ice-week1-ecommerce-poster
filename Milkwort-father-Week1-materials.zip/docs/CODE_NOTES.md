# GitHub 与重绘代码说明

## 本包脚本

- 文件：`src/plot_week1_assets.py`
- 功能：读取 `data/` 中两份 CSV，重新生成 `assets/figures/` 中主图与备用图。
- 语言：Python 3。
- 依赖：matplotlib、numpy；见 `requirements.txt`。
- 是否清洗数据：只做 CSV 读取和数值类型转换，不插值、不平滑、不修改原始公开数值。
- 是否可直接运行：可以。在仓库根目录执行：

```bash
python -m pip install -r requirements.txt
python src/plot_week1_assets.py
```

## 上游 GitHub 仓库

- 仓库：[uncomtrade/comtradeapicall](https://github.com/uncomtrade/comtradeapicall)
- 本仓库不再嵌套保存上游 ZIP；请通过仓库链接访问其最新版本。
- 许可证：MIT（代码）；UN Comtrade 数据条款另行适用。
- 示例：[Top traded products](https://github.com/uncomtrade/comtradeapicall/blob/main/examples/example%20tracking%20top%20traded%20products.ipynb)
- 示例：[Bilateral trade matrix](https://github.com/uncomtrade/comtradeapicall/blob/main/examples/example%20bilateral%20trade%20matrix%20view.ipynb)
- 主要库：pandas、urllib3、comtradeapicall。
- 运行限制：免费/预览 API 与完整 API 的调用数量、行数和 key 要求可能不同。

## 必须注意

UN Comtrade 是一般商品贸易数据库，并不专门识别“跨境电商”交易。因此，该仓库只能用来补充中国与伙伴国的总体商品流向，不能把输出直接标成跨境电商规模。海报主图应继续使用本包海关跨境电商序列。
