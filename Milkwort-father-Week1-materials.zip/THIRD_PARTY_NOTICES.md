# Third-party materials and reuse notice

本仓库没有对全部内容授予统一的开源许可证。上传者和使用者应分别遵守下列来源的权利与使用条款。

## Government statistics and report

- 中国海关总署 2020—2024 年跨境电商进出口公开统计。
- 中华人民共和国商务部《中国电子商务报告（2024）》及其公开 PDF。
- 上述网页和报告未在本仓库确认统一开放许可证；在课堂海报中应署名，进一步公开、出版或商业使用前应重新核查许可。

## IPC and HKTDC materials

- IPC Cross-Border E-commerce Shopper Survey 2023。
- HKTDC Research, *Digital Trade Transformation: Opportunities and Challenges* (2024)。
- 本仓库只从公开材料整理汇总数字；不包含 IPC 微观调查数据。公开演示稿和调查图表的改编许可待核查。

## Full reports are linked, not redistributed

为降低公开 GitHub 仓库的再分发风险，本仓库未打包商务部与 HKTDC 的完整 PDF，只在 `references/README.md` 和说明文档中保留发布方链接。若链接内容的权利条款发生变化，应以发布方最新说明为准。

## UN Comtrade code references

- 上游仓库：<https://github.com/uncomtrade/comtradeapicall>
- 该仓库代码标注为 MIT License；UN Comtrade 数据条款与代码许可证分开适用。
- 本仓库没有复制或重新分发完整的上游仓库压缩包，仅保留链接。

## Repository-created files

`src/plot_week1_assets.py` 和 `assets/figures/` 中的图表是依据已署名的公开汇总数字制作。除非仓库所有者另行声明，本说明不构成对这些原创文件的公开许可授权。
