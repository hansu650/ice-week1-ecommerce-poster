# Week 1 Materials

Topic: From Domestic Scale to Global Reach: How China's Cross-border E-commerce Is Reshaping Global Retail

Main source:
- UNCTAD, Business e-commerce sales and the role of online platforms, 2024
- PDF: https://unctad.org/system/files/official-document/dtlecde2024d3_en.pdf
- Suggested poster figure: Figure 1, E-commerce sales by businesses, 2016-2022
- License stated in PDF: Creative Commons Attribution 3.0 IGO

Dataset:
- UNCTADstat, E-commerce: Domestic and international sales - Annual (analytical)
- Data viewer: https://unctadstat.unctad.org/datacentre/dataviewer/US.ECommerceTotal/
- Metadata: https://unctadstat-api.unctad.org/api/reportMetadata/US.ECommerceTotal/en
- Suggested chart: China domestic vs international e-commerce sales trend, or international share of total e-commerce sales.

Backup source:
- UNCTAD technical note PDF included as a backup reference.

Privacy check:
- This package contains only public UNCTAD PDFs and this README.
- No passwords, tokens, student IDs, phone numbers, or private chat logs are included.
