# -*- coding: utf-8 -*-
"""
Discrete Simulation: Small-Batch Agile Sourcing (LATR) vs Traditional Bulk Forecasting
Demonstrating how On-demand manufacturing eliminates unsold inventory waste.
"""

import random

def simulate_supply_chains(trials=1000):
    shein_waste_total = 0
    traditional_waste_total = 0
    
    for _ in range(trials):
        actual_demand = max(0, int(random.gauss(500, 200)))
        
        # 1. Traditional Bulk Ordering (Pre-season forecast: fixed 800 pcs)
        trad_order = 800
        trad_unsold = max(0, trad_order - actual_demand)
        traditional_waste_total += (trad_unsold / trad_order)
        
        # 2. SHEIN LATR Model (Initial test: 150 pcs, algorithmic restock matching demand)
        test_batch = 150
        if actual_demand <= test_batch:
            shein_unsold = test_batch - actual_demand
            shein_produced = test_batch
        else:
            restock = actual_demand - test_batch
            shein_unsold = 0
            shein_produced = test_batch + restock
        shein_waste_total += (shein_unsold / shein_produced)
        
    print(f"Simulation Results over {trials} SKUs:")
    print(f"- Traditional Retail Average Waste Rate: {traditional_waste_total/trials * 100:.1f}%")
    print(f"- SHEIN / Temu Agile LATR Waste Rate:     {shein_waste_total/trials * 100:.1f}%")

if __name__ == '__main__':
    simulate_supply_chains()
