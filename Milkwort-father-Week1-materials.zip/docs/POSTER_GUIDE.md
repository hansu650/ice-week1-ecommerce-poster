# Week 1 海报使用建议

## 推荐叙事

1. **Domestic Scale**：2020—2024 年中国跨境电商进出口从 1.69 万亿元增至 2.63 万亿元，CAGR 约 11.7%。
2. **Global Reach**：IPC 趋势数据显示，最近一次跨境网购来自中国的受访者比例从 26% 增至 37%。
3. **Global Retail Impact**：跨境平台、数字支付、国际物流、海外仓和数据驱动选品缩短了中国供应商与海外消费者之间的链路。
4. **Balanced View**：规模扩张同时带来合规、产品安全、退货、税务、平台治理和可持续物流等挑战。

## 推荐版式

- **顶部 15%：** 英文题目、三位关键数字、组员姓名。
- **左侧 50%：** 主折线图，并用一句话解释“近乎翻倍”。
- **右上 20%：** 2.63 万亿元、11.7%、6% 三个 KPI。
- **右下 25%：** IPC 26%→37% 备用图，以及“not market share”小字提醒。
- **底部 10%：** 影响机制、风险平衡、Harvard 风格简短来源。

## 可直接使用的英文文案

**Key finding**

> China’s cross-border e-commerce imports and exports rose from RMB 1.69 trillion in 2020 to RMB 2.63 trillion in 2024, equivalent to an 11.7% compound annual growth rate.

**Global reach**

> In IPC’s trend sample, the share of consumers whose most recent cross-border online purchase came from China increased from 26% in 2016 to 37% in 2023.

**Industry impact**

> Digital platforms, integrated logistics and data-driven supply chains are enabling Chinese sellers to reach overseas consumers more directly, increasing product variety and price competition across global retail.

**Caveat**

> The 2024 trade value is preliminary. The IPC figure is a respondent share, not China’s share of global e-commerce sales.

## Harvard 参考文献示例

- General Administration of Customs of the People’s Republic of China (2025) *China’s foreign trade in 2024*. Available at: https://www.customs.gov.cn/customs/2025-01/14/article_2025121410054066028.html (Accessed: 1 September 2026).
- International Post Corporation (2023) *Cross-Border E-commerce Shopper Survey 2023*. Available at: https://www.ipc.be/services/business-framework/cross-border-shopper-survey/2023 (Accessed: 1 September 2026).
- Fan, I. (2024) *Digital Trade Transformation: Opportunities and Challenges*. HKTDC Research. Available at: https://www.aof.org.hk/docs/default-source/hkimr/conference-workshop/panel-2_1_irina-fan.pdf?sfvrsn=315bce5b_2 (Accessed: 1 September 2026).

## 提交前检查

- 全部组员姓名已放在海报上。
- 海报已导出为清晰 PNG/JPG，并准备插入 Reflection Template。
- 已拍摄一张或多张小组制作过程照片作为 evidence。
- 图下方有来源，且术语与统计口径没有夸大。
- 个人约 300 词反思由本人撰写，包含活动前/中/后感受、所学内容和未来应用。

